$(function() {

	jQuery('ol.test-list').children(':first-child').addClass('test');
	jQuery('ol.test-list').children(':nth-child(even)').addClass('even');
	jQuery('ol.test-list').children(':nth-child(odd)').addClass('odd');
	jQuery('ol.test-list').children(':nth-last-child(3)').addClass('expr');

});

// jQuery nth-last-child selector
jQuery.expr[':']['nth-last-child'] = function(elem, index, match) {
    var parent = elem.parentNode, children = parent.children, expr = match[3];
    $.each(children, function(ind, obj) {
        if(obj === elem) {
            index = ind;
            return false;
        }
    });
    if(expr.indexOf('n') != -1) {
        return jQuery(parent).children(':nth-child(' + expr + ')').filter(elem).length > 0;
    } else {
        return children[children.length - expr] === elem;
    }
};