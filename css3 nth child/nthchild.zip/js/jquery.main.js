// page init
jQuery(function(){
	initChildClasses();
});

// add classes to support css3 selectors in old browsers
function initChildClasses() {
	jQuery('#nav').children(':last-child').addClass('last-child');
	jQuery('#nav').children(':even').addClass('even');
}