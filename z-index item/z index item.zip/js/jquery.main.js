// page init
jQuery(function(){
	initItemsZindex();
});

// add z-index to elements
function initItemsZindex() {
	jQuery('#nav li').zIndexOrder();
	jQuery('#nav li').zIndexOrder({
		startIndex: 100,
		reverse: true
	});
}

// zIndex order plugin
jQuery.fn.zIndexOrder = function(opt) {
	var options = jQuery.extend({
		reverse: false,
		startIndex: 0
	}, opt);

	var items = this;
	return items.each(function(index, item) {
		items.eq(options.reverse ? items.length - index - 1 : index).css({
			zIndex: index + (options.startIndex || 1)
		});
	});
};