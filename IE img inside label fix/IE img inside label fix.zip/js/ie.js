// fix images inside label click behavior 
if(window.attachEvent && !window.addEventListener) {
	window.attachEvent('onload', function(){
		var labels = document.getElementsByTagName('label');

		var fixLabel = function(label, image) {
			image.onclick = function () {
				label.click();
			};
		};

		for(var i = 0, label, image; i < labels.length; i++) {
			label = labels[i];
			image = label.getElementsByTagName('img')[0];
			if(image) {
				fixLabel(label, image);
			}
		}
	});
}
