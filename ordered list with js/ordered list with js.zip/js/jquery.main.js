// page init
jQuery(function(){
	initNumberedLists();
});

// build custom structure for numbered lists
function initNumberedLists() {
	jQuery('ol.list').numberedList({
		wrapTag: 'span'
	});
	jQuery('.list').numberedList({
		symbol: '=',
		wrapTag: 'span',
		zeroLeadIndex: false
	});
}

/*
 * Custom numbered list module
 */
;(function($) {
	function NumberedList(options) {
		this.options = $.extend({
			list: null,
			symbol: '.',
			wrapTag: 'span',
			wrapClass: 'ol-item-index',
			moduleActiveClass: 'ol-custom-structure',
			zeroLeadIndex: true
		}, options);
		if(this.options.list) {
			this.initStructure();
		}
	}
	NumberedList.prototype = {
		initStructure: function() {
			var self = this;
			this.list = $(this.options.list).addClass(this.options.moduleActiveClass);
			this.items = this.list.children();
			this.startIndex = parseInt(this.list.attr('start'), 10);
			if(isNaN(this.startIndex)) {
				this.startIndex = 1;
			}
			this.items.each(function(index, item) {
				var textBlock = jQuery(document.createElement(self.options.wrapTag));
				var slideIndex = self.startIndex + index;

				if(self.options.zeroLeadIndex) {
					slideIndex = slideIndex < 10 && slideIndex >= 0 ? '0' + slideIndex : slideIndex;
				}
				textBlock.addClass(self.options.wrapClass).text(slideIndex + self.options.symbol).prependTo(item);
			});
		}
	};

	// jquery pluginm interface
	$.fn.numberedList = function(opt) {
		return this.each(function() {
			new NumberedList($.extend({list: this}, opt));
		});
	};
}(jQuery));