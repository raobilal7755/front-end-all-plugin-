// page init
jQuery(function(){
	initCufon();
});

// cufon replace init
function initCufon() {
	Cufon.replace('h1, h2', { fontFamily: 'Arial' });
	Cufon.replace('h1, h2', { fontFamily: 'Arial', hover: true });

	// refresh cufon on hover
	var fixHover = function(elementSelector, cufonSelector) {
		jQuery(elementSelector).mouseout(function() {
			setTimeout(function() {
				Cufon.refresh(cufonSelector)
			}, 10);
		});
	};
	fixHover('.box', 'h1, h2');
}