/*
 * Window Height CSS rules
 */
;(function() {
	var styleSheet;

	var getWindowHeight = function() {
		return window.innerHeight || document.documentElement.clientHeight;
	};

	var createStyleTag = function() {
		// create style tag
		var styleParent = document.getElementsByTagName('head')[0],
			styleTag = document.createElement('style');

		// get stylesheet
		styleParent.appendChild(styleTag);
		styleSheet = styleTag.sheet || styleTag.styleSheet;

		// crossbrowser style handling
		var addCSSRule = function(selector, rules, index) {
			if(styleSheet.insertRule) {
				styleSheet.insertRule(selector + '{' + rules + '}', index);
			} else {
				styleSheet.addRule(selector, rules, index);
			}
		};

		// create style rules
		addCSSRule('.win-min-height', 'min-height:0');
		addCSSRule('.win-height', 'height:auto');
		addCSSRule('.win-max-height', 'max-height:100%');
		resizeHandler();
	};

	var resizeHandler = function() {
		// handle changes on style rules
		var currentWindowHeight = getWindowHeight(),
			styleRules = styleSheet.cssRules || styleSheet.rules;
		
		for(var i = 0, currentRule, currentProperty; i < styleRules.length; i++) {
			currentRule = styleRules[i];
			currentProperty = currentRule.selectorText.toLowerCase().replace('.win-', '').replace('-h','H');
			currentRule.style[currentProperty] = currentWindowHeight + 'px';
		}
	};

	createStyleTag();
	if(window.addEventListener) {
		addEventListener('resize', resizeHandler, false);
		addEventListener('orientationchange', resizeHandler, false);
	} else if(window.attachEvent) {
		attachEvent('onresize', resizeHandler);
	}
}());