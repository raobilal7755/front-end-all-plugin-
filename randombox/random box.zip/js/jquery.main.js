// page init
jQuery(function(){
	initRandomBox();
});

// random element init
function initRandomBox() {
	jQuery('ul.random-quote > li').randomBox({
		type: 'random'
	});
	jQuery('ul.random-quote > li').randomBox({
		type: 'reorder'
	});
}

/*
 * jQuery RandomBox plugin
 */
;(function($){
	$.fn.randomBox = function(o) {
		var options = $.extend({
			type: 'random'
		},o);
		
		// show random block
		if(options.type === 'random') {
			var randomIndex = getRandomInt(0, this.length - 1);
			this.hide().eq(randomIndex).show();
		}
		// randomly sort blocks
		else {
			var holder = this.parent();
			var elements = this;
			var elementsCount = elements.length;
			if (elementsCount > 1) {
				elements.remove();
				var indices = [];
				for (i = 0; i < elementsCount; i++) {
					indices[indices.length] = i;
				}
				indices = indices.sort(getRandomOrd);
				$(indices).each(function(j,k) {
					holder.append(elements.eq(k));
				});
			}
		}
		return this;
	}
	function getRandomInt(min, max) {
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}
	function getRandomOrd() {
		return(Math.round(Math.random())-0.5); 
	}
}(jQuery));