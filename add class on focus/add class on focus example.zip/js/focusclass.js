// page init
function initPage(){
	initFocusClass();
}

// add class when element is in focus
function initFocusClass() {
	AddFocusClass({
		holder: '.field',
		element: 'input[type="text"]',
		focusClass: 'focus'
	});
}

/*
 * AddFocusClass module
 */
function AddFocusClass(options) {
	var holders = document.querySelectorAll(options.holder),
		currentParent, currentElement;

	var addFocusHandlers = function(parentNode, elementNode) {
		var focusHandler = function() {
			parentNode.className += ' ' + options.focusClass;
		};
		var blurHandler = function() {
			parentNode.className = parentNode.className.replace(new RegExp('\\b' + options.focusClass + '\\b', 'g'), '');
		};

		if(elementNode.addEventListener) {
			elementNode.addEventListener('focus', focusHandler, false);
			elementNode.addEventListener('blur', blurHandler, false);
		} else if(elementNode.attachEvent) {
			elementNode.attachEvent('onfocus', focusHandler);
			elementNode.attachEvent('onblur', blurHandler);
		}
	};

	for(var i = 0; i < holders.length; i++) {
		currentParent = holders[i];
		currentElement = currentParent.querySelector(options.element);
		if(currentElement) {
			addFocusHandlers(currentParent, currentElement);
		}
	}
}

if(window.addEventListener) window.addEventListener('load', initPage, false);
else if(window.attachEvent) window.attachEvent('onload', initPage);