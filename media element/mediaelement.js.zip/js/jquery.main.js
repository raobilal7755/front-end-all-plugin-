jQuery(function() {
	jQuery('video,audio').mediaelementplayer({
		pluginPath: 'js/'
	});
});